Fill in the required details at the appropriate places in report.tex
There is a separate .tex corresponding to each chapter. 
Each chapter should be divided into sections, and subsections.
 
